#include "usb.h"
#include "HardwareProfile.h"
#include "usb_function_hid.h"

//------------------USB USER CALLBACK DEFINES-----------------------
#define DEFINE_GET_REPORT_HANDLER USER_GET_REPORT_HANDLER()
#define DEFINE_SET_REPORT_HANDLER USER_SET_REPORT_HANDLER()
   
   

//------------------JOYSTICK DEFINES-----------------------
//http://www.microsoft.com/whdc/archive/hidgame.mspx
#define HAT_SWITCH_NORTH            0x0
#define HAT_SWITCH_NORTH_EAST       0x1
#define HAT_SWITCH_EAST             0x2
#define HAT_SWITCH_SOUTH_EAST       0x3
#define HAT_SWITCH_SOUTH            0x4
#define HAT_SWITCH_SOUTH_WEST       0x5
#define HAT_SWITCH_WEST             0x6
#define HAT_SWITCH_NORTH_WEST       0x7
#define HAT_SWITCH_NULL             0x8
//------------------JOYSTICK DATA-----------------------
typedef union _JOYSTICK
{
    struct
    {
		struct
        {
        	BYTE RID;
        }REPORT_ID;
        struct
        {
            BYTE square:1;
            BYTE x:1;
            BYTE o:1;
            BYTE triangle:1;
            BYTE L1:1;
            BYTE R1:1;
            BYTE L2:1;
            BYTE R2:1;//
            BYTE select:1;
            BYTE start:1;
            BYTE left_stick:1;
            BYTE right_stick:1;
            BYTE home:1;
            BYTE :3;    //filler
        } buttons;
        struct
        {
            BYTE hat_switch:4;
            BYTE :4;//filler
        } hat_switch;
        struct
        {
            unsigned short int X;
            unsigned short int Y;
            unsigned short Z;
            unsigned short Rz;
        } analog_stick;
    } members;
   BYTE val[12];
}JOYSTICK_UNION;
