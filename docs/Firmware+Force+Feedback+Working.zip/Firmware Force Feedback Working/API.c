#include "API.h"
#include <adc.h>
#include <delays.h>


typedef union _set_condition_report
{
	struct
	{
		BYTE report_id;
		BYTE usage_effect_block_index;
		BYTE parameter_block_offset_ordinals; // high 4 bits |low 4 bits
		BYTE cp_offset;
		BYTE positive_coefficient;
		BYTE negative_coefficient;
		BYTE positive_saturation;
		BYTE negative_saturation;
		BYTE dead_band;
	}set_condition_struct;
BYTE array_entry[9];
}_SET_CONDITION_REPORT;

typedef union _set_effect_report
{
	struct
	{
		BYTE report_id;//1
		BYTE effect_block_index;//2
		BYTE effect_type;//3
		short int duration;//4-5
		short int trigger_repeat_interval;//6-7
		short int sample_period;//8-9
		BYTE gain;//10
		
		BYTE trigger_button;//11
		BYTE axes_enable_direction; //0b X|Y|Dir|00000 //12
		BYTE direction_with_ordinals_1;// X axis//13
		BYTE direction_with_ordinals_2;//Y axis//14
		short int usage_undefined_1;// no ideea//15
	}set_effect_report;
	BYTE array_entry[16];
} _SET_EFFECT_REPORT;


typedef union _set_custom_force_report
{
	struct
	{
		BYTE report_id;
		BYTE effect_block_index;
		short int custom_force_data_offset;
		BYTE custom_force_data[12];

	}set_custom_force_report;
	BYTE array_entry[16];
} _SET_CUSTOM_FORCE_REPORT;

typedef union _set_constant_force_report
{
	struct
	{
		BYTE report_id;
		BYTE effect_block_index;
		short int magnitude;
		
	}set_constant_force_report;
	BYTE array_entry[4];
} _SET_CONSTANT_FORCE_REPORT;


typedef union _set_periodic_force_report
{
	struct
	{
		BYTE report_id;
		BYTE effect_block_index;
		BYTE magnitude;
		BYTE offset;
		BYTE phase;
		short int period;
	}set_periodic_force_report;
	BYTE array_entry[7];
} _SET_PERIODIC_FORCE_REPORT;




#pragma udata USB_VARIABLES=0x500
JOYSTICK_UNION joystick_input; // 
BYTE hid_report[20]; // buffer for hid reports
BYTE pid_report[20]; // buffer for pid reports

USB_HANDLE USBOutHandle = 0;
USB_HANDLE USBInHandle = 0;
USB_HANDLE USBEP0OutHandle = 0;
USB_HANDLE USBEP0InHandle = 0;




#pragma udata usb6=0x600
_SET_EFFECT_REPORT SET_EFFECT_REPORT[12]; //18 byte

#pragma udata usb7
_SET_CUSTOM_FORCE_REPORT SET_CUSTOM_FORCE_REPORT[12];
_SET_CONSTANT_FORCE_REPORT SET_CONSTANT_FORCE_REPORT[12];

#pragma udata 
BYTE FFB_IS_INIT;
BYTE FFB_WAIT_CONFIGURATION;
BYTE STOP_FUCK_ALL;
unsigned int FFB_CONFIGURED_COUNTDOWN;
BYTE FFB_START_COMMANDS;
BYTE PID_POOL_REPORT[6];
BYTE EFFECT_ON_ARRAY[12];
BYTE PID_BLOCK_LOAD_REPORT[4];
_SET_CONDITION_REPORT SET_CONDITION_REPORT[12];// 9 byte
_SET_PERIODIC_FORCE_REPORT SET_PERIODIC_FORCE_REPORT[12];
char temp_char;
short int CONFIGURED_EFFECT_NUMBER;


BYTE EP1_DATA_RECEIVED_STATUS;// 0 not received. 1 waiting for transaction to complete. 2 data is ready
BYTE EP1_DATA_SERVICED;
BYTE EP1_DATA_OWNERSHIP;

#pragma code

void API_STOP_EFFECT(char effect_off)
{
 EFFECT_ON_ARRAY[effect_off]=0;
 T3CONbits.TMR3ON=0;	//Timer3 On bit
 T1CONbits.TMR1ON=0;	//Timer1 On bit
 PORTAbits.RA2=0;
 PORTAbits.RA3=0;
 PORTAbits.RA4=0;
}

void API_START_EFFECT(char effect_on)
{
 EFFECT_ON_ARRAY[effect_on]=1;
 
 T3CONbits.TMR3ON=1;	//Timer3 On bit
 T1CONbits.TMR1ON=1;	//Timer1 On bit
}
void API_PLAY_EFFECTS(void)
{

 for(temp_char=0;temp_char<12;temp_char++)
 {
	if(EFFECT_ON_ARRAY[temp_char])
    {
	 PORTAbits.RA2=SET_EFFECT_REPORT[temp_char].array_entry[12]>128?1:0;
	 PORTAbits.RA3=SET_EFFECT_REPORT[temp_char].array_entry[13]>128?1:0;
	 TMR1H=	0xFF-SET_CONSTANT_FORCE_REPORT[temp_char].array_entry[2];
	 TMR1L=	0xFF/*SET_CONSTANT_FORCE_REPORT[temp_char].array_entry[3]*/;
	}
 }
}

void API_PLAY_EFFECTS2(void)
{

 for(temp_char=0;temp_char<12;temp_char++)
 {
	if(EFFECT_ON_ARRAY[temp_char])
    {
	 TMR1H=	SET_CONSTANT_FORCE_REPORT[temp_char].array_entry[2];
	 TMR1L=	0xFF/*SET_CONSTANT_FORCE_REPORT[temp_char].array_entry[3]*/;
	}
 }
 
}
void API_JOYSTICK_TASKS(void)
{
			joystick_input.members.REPORT_ID.RID=1;
			// RESET JOYSTICK DATA
			joystick_input.val[1]=0;
			joystick_input.val[2]=0;
			joystick_input.val[3]=0;

		//-------------------------------------- PASSIVE READING OF DATA SENT TO ME -----------------------------
		
		
		//--------------------------------------READ AXIS WITH ADC--------------------------------------------------------
			//ANALOG AXIS ON RA0/RA1/RA2/

			// ---------------------------------X AXIS :  [    SELECT CHANNEL RA-0    ]----------------------------------
		
	 	
			SelChanConvADC(ADC_CH0);
			ConvertADC();
			while(BusyADC()){};  //wait for the conversion to end
			//Combine the 10 bits of the conversion and set the result to X AXIS
			joystick_input.members.analog_stick.X	=	ReadADC() ;

			// ---------------------------------Y AXIS :  [    SELECT CHANNEL RA-1    ]----------------------------------
		
	 	
		
			
			SelChanConvADC(ADC_CH1);
			ConvertADC();
			while(BusyADC()){};  //wait for the conversion to end
			//Combine the 10 bits of the conversion and set the result to X AXIS
			joystick_input.members.analog_stick.Y	=	ReadADC() ;

			// ---------------------------------Z AXIS :  [    SELECT CHANNEL RA-2    ]----------------------------------
			
	 
			/*
			SelChanConvADC(ADC_CH2);
			ConvertADC();
			while(BusyADC()){};  //wait for the conversion to end
			//Combine the 10 bits of the conversion and set the result to X AXIS
			joystick_input.members.analog_stick.Z	= ReadADC() ;
		
			//----------------------------------------------------------------------------------------------
		
			// ---------------------------------Rz AXIS :  [    SELECT CHANNEL RA-3    ]----------------------------------
		
		joystick_input.members.analog_stick.Rz=joystick_input.members.analog_stick.Rz+1;
		
			SelChanConvADC(ADC_CH2);
			ConvertADC();
			while(BusyADC()){};  //wait for the conversion to end
			//Combine the 10 bits of the conversion and set the result to X AXIS
			joystick_input.members.analog_stick.Rz	=ReadADC() ;
		*/
	 		
    //If the last transmision is complete

    if(!HIDTxHandleBusy(USBOutHandle))
    {
       
      
            //Indicate that the "x" button is pressed, but none others
            joystick_input.members.buttons.x = 0;
            joystick_input.members.buttons.square = 0;
            joystick_input.members.buttons.o = 0;
            joystick_input.members.buttons.triangle = 0;
            joystick_input.members.buttons.L1 = 0;
            joystick_input.members.buttons.R1 = 0;
            joystick_input.members.buttons.L2 = 0;
            joystick_input.members.buttons.R2 = 0;
            joystick_input.members.buttons.select = 0;
            joystick_input.members.buttons.start = 0;
            joystick_input.members.buttons.left_stick = 0;
            joystick_input.members.buttons.right_stick = 0;
            joystick_input.members.buttons.home = 0;

            //Move the hat switch to the "east" position
            joystick_input.members.hat_switch.hat_switch = HAT_SWITCH_EAST;
           	//Send the packet over USB to the host.
           	USBOutHandle = HIDTxPacket(HID_EP, (BYTE*)&joystick_input, sizeof(joystick_input));
    }
}


void API_USER_SERVICE_EP1_RECEIVED_DATA(void)
{
 if(((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1)))
 {
  return;
 }
 if(EP1_DATA_RECEIVED_STATUS==2)// if i received data on EP1, and it's status is data ready, i will have the data on hid_report[] buffer
 {
   switch(hid_report[0])// check the report ID sent in the data stage
   {
	case 0x03://Usage Set Effect Report
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[0]=hid_report[0];// report id
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[1]=hid_report[1];//effect block index
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[2]=hid_report[2];//effect type
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[3]=hid_report[3];//duration high
		 	 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[4]=hid_report[4];//duration low
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[5]=hid_report[5];//trig.rep.int high
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[6]=hid_report[6];//trig.rep.int low
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[7]=hid_report[7];//sample period high
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[8]=hid_report[8];//sample period low
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[9]=hid_report[9];//gain
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[10]=hid_report[10];//trig.button
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[11]=hid_report[11];//axis enable+dir
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[12]=hid_report[12];//ordinals 1
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[13]=hid_report[13];//ordinals 2
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[14]=hid_report[14];//undefined 1 high
			 SET_EFFECT_REPORT[hid_report[1]-1].array_entry[15]=hid_report[15];//undefined 1 low
			 EP1_DATA_SERVICED=1; // i serviced this data
	break;
	case 0x05://Usage Set Condition Report

			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[0]=hid_report[0];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[1]=hid_report[1];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[2]=hid_report[2];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[3]=hid_report[3];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[4]=hid_report[4];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[5]=hid_report[5];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[6]=hid_report[6];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[7]=hid_report[7];
			 SET_CONDITION_REPORT[hid_report[1]-1].array_entry[8]=hid_report[8];
			 EP1_DATA_SERVICED=1; // i serviced this data
	break;
	case 0x06: //Usage Set Periodic Report
			 SET_PERIODIC_FORCE_REPORT[hid_report[1]-1].array_entry[0]=hid_report[0];// report id
			 SET_PERIODIC_FORCE_REPORT[hid_report[1]-1].array_entry[1]=hid_report[1];//effect block index
			 SET_PERIODIC_FORCE_REPORT[hid_report[1]-1].array_entry[2]=hid_report[2];//magnitude
			 SET_PERIODIC_FORCE_REPORT[hid_report[1]-1].array_entry[3]=hid_report[3];//offset
			 SET_PERIODIC_FORCE_REPORT[hid_report[1]-1].array_entry[4]=hid_report[4];//phase
			 SET_PERIODIC_FORCE_REPORT[hid_report[1]-1].array_entry[5]=hid_report[5];//period high byte
			 SET_PERIODIC_FORCE_REPORT[hid_report[1]-1].array_entry[6]=hid_report[6];//period low byte
			 EP1_DATA_SERVICED=1; // i serviced this data
	break;
	case 0x07://Usage Set Constant Force Rep
			 SET_CONSTANT_FORCE_REPORT[hid_report[1]-1].array_entry[0]=hid_report[0];// report id
			 SET_CONSTANT_FORCE_REPORT[hid_report[1]-1].array_entry[1]=hid_report[1];//effect block index
			 SET_CONSTANT_FORCE_REPORT[hid_report[1]-1].array_entry[2]=hid_report[2];//magnitude high byte
			 SET_CONSTANT_FORCE_REPORT[hid_report[1]-1].array_entry[3]=hid_report[3];//magnitude low byte
			 
			 EP1_DATA_SERVICED=1; // i serviced this data
	break;
    case 0x09://Usage Custom Force  Report
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[0]=hid_report[0];// report id
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[1]=hid_report[1];//effect block index
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[2]=hid_report[2];//custom force data offset high
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[3]=hid_report[3];//custom force data offset low
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[4]=hid_report[4];//custom force data 0
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[5]=hid_report[5];//custom force data 1
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[6]=hid_report[6];//custom force data 2
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[7]=hid_report[7];//custom force data 3
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[8]=hid_report[8];//custom force data 4
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[9]=hid_report[9];//custom force data 5
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[10]=hid_report[10];//custom force data 6
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[11]=hid_report[11];//custom force data 7
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[12]=hid_report[12];//custom force data 8
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[13]=hid_report[13];//custom force data 9
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[14]=hid_report[14];//custom force data 10
			 SET_CUSTOM_FORCE_REPORT[hid_report[1]-1].array_entry[15]=hid_report[15];//custom force data 11
			 EP1_DATA_SERVICED=1; // i serviced this data
	break;
    case 0x0B: // Effect Operation Report
		     switch(hid_report[2])// hid_report[2] contains Usage Effect Operation
			 {
			   case 1: // start
					 API_START_EFFECT(hid_report[1]-1);	
			   break;
			   case 2: // start solo
			   break;
			   case 3: // stop
					 API_STOP_EFFECT(hid_report[1]-1);
			   break;
			 }
			 EP1_DATA_SERVICED=1; // i serviced this data
			// ok, here it tells me to start the effect
			// after this, it sends me the data to configure for the effect with a 0x03							
	break;
	case 0x0C: // Effect Operation Report
			 // bypass_shit=1;
			 // STOP_FUCK_ALL=1;
			 EP1_DATA_SERVICED=1; // i serviced this data
	break;
    case 0x0D: // Usage PID Device Control ( first command of this is a device reset... later... )
			 EP1_DATA_SERVICED=1; // i serviced this data
    break;
    case 0x0E:// Usage Device Gain Report
			 EP1_DATA_SERVICED=1; // i serviced this data
    break;		
   }
   if(EP1_DATA_SERVICED)// if the data has been serviced, read next packet
   {
    EP1_DATA_RECEIVED_STATUS=0; // rearm the reading function to get the next packet
   }
   else// data has not been serviced, driver will stall waiting for a response that never comes
   {
   }
 }
}

void API_READ_EP1_DATA(void)
{
 if(((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1)))
 {
  return;
 }
 if(!EP1_DATA_RECEIVED_STATUS)// if the data has not been received
 {
  if(EP1_DATA_SERVICED)// only if the data has been serviced, read the next packet. on startup, dataserviced=1
  {
   if(!HIDRxHandleBusy(USBInHandle))//wait for last read to complete. the read is in a BDT independend of EP0...
   {	
	USBInHandle=HIDRxPacket(HID_EP, (BYTE*)&hid_report[0], 20);
	EP1_DATA_RECEIVED_STATUS=1; // wait for data to complete;
	EP1_DATA_SERVICED=0;// start the servicing of data
   }
  }
 }
 if(EP1_DATA_RECEIVED_STATUS==1)// i did a read, and i'm waiting for the transfer of data to complete
 {
  if(!HIDRxHandleBusy(USBInHandle))//wait for last read to complete. the read is in a BDT independend of EP0...
  {
   EP1_DATA_RECEIVED_STATUS=2; // if i'm waiting for data, and data has arrived, set status to data ready..._STATUS=2;
  }
 }
}


void USBSetEffect(void)
{
	/*
		pid_report[0] // report id PID BLOCK LOAD REPORT
		pid_report[1] //effect type

		PID_BLOCK_LOAD_REPORT[0] // report id PID BLOCK LOAD REPORT
		PID_BLOCK_LOAD_REPORT[1] // effect block index
		PID_BLOCK_LOAD_REPORT[2] // block load status
		PID_BLOCK_LOAD_REPORT[3] // ram pool available
	*/
	PID_BLOCK_LOAD_REPORT[0]=0x11;
switch(pid_report[1]) // switch effect type
{ 
case 1:// Usage ET Constant Force 0
		PID_BLOCK_LOAD_REPORT[1]=1; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000000000001; // 2 byte
break;
case 2:// Usage ET Ramp 1
		PID_BLOCK_LOAD_REPORT[1]=2; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000000000010; // 2 byte
break;
case 3:// Usage ET Square 2
		PID_BLOCK_LOAD_REPORT[1]=3; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000000000100; // 2 byte
break;
case 4:// Usage ET Sine 3
	
		PID_BLOCK_LOAD_REPORT[1]=4; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000000001000; // 2 byte
break;
case 5:// Usage ET Triangle 4
		PID_BLOCK_LOAD_REPORT[1]=5; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000000010000; // 2 byte
break;
case 6:// Usage ET Sawtooth Up 5
		PID_BLOCK_LOAD_REPORT[1]=6; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000000100000; // 2 byte
break;
case 7:// Usage ET Sawtooth Down 6
		PID_BLOCK_LOAD_REPORT[1]=7; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000001000000; // 2 byte
break;
case 8:// Usage ET Spring 7
		PID_BLOCK_LOAD_REPORT[1]=8; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000010000000; // 2 byte
break;
case 9:// Usage ET Damper 8
		PID_BLOCK_LOAD_REPORT[1]=9; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000000100000000; // 2 byte
break;
case 10:// Usage ET Inertia 9
		PID_BLOCK_LOAD_REPORT[1]=10; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000001000000000; // 2 byte
break;
case 11:// Usage ET Friction 10
		PID_BLOCK_LOAD_REPORT[1]=11; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=1; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0xFF; // i still have ram...
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER |0b0000010000000000; // 2 byte
break;
case 12:// Usage ET Custom Force Data 11 ! NOT SUPPORTED BY THIS DEVICE !
		PID_BLOCK_LOAD_REPORT[1]=0; // 0:can't create effect | 1-12 = effect block index 
		PID_BLOCK_LOAD_REPORT[2]=3; // 3:can't create effect | 1: can create effect
		PID_BLOCK_LOAD_REPORT[3]=0x00; // no more ram
		// buffer to keep track of configured effects. 1 bit x effect , in same order as descriptor
		CONFIGURED_EFFECT_NUMBER=CONFIGURED_EFFECT_NUMBER & 0b1111011111111111; // 2 byte// clear 12th bit
// now, when the host issues a get_report , i send the set_get_effect_structure.PID_BLOCK_LOAD_REPORT.
break;
} 

}

//-----------------------USB USER FUNCTIONS / CALLBACKS--------------------------
void USER_GET_REPORT_HANDLER(void)
{


 switch(SetupPkt.W_Value.byte.LB)  
 {
   case 0x11:// REPORT ID  PID_BLOCK_LOAD_STATUS
	switch(SetupPkt.W_Value.byte.HB) // REPORT TYPE 
	{
	 case 0x01:// INPUT REPORT
	 break;
	 case 0x02: // OUTPUT, the host wants to send me the data
	 break;
	 case 0x03:// FEATURE, the host wants ME to send the data

		 pid_report[0]=PID_BLOCK_LOAD_REPORT[0]; // PID BLOCK LOAD REPORT ID
		 pid_report[1]=PID_BLOCK_LOAD_REPORT[1]; // EFFECT INDEX
		 pid_report[2]=PID_BLOCK_LOAD_REPORT[2]; // SUCCESS/FAIL STATUS
		 pid_report[3]=PID_BLOCK_LOAD_REPORT[3]; // AVAILABLE RAM
		
		 USBDeviceTasks();
			 
		 USBEP0SendRAMPtr((BYTE*)&pid_report[0], 4, USB_EP0_NO_OPTIONS);					
	 break;
	} 
    break;
   case 0x22:// REPORT ID  PID_POOL_REPORT
	
	PID_POOL_REPORT[0]=0x22;	// report ID
	PID_POOL_REPORT[1]=120;		// RAM POOL SIZE 120
	PID_POOL_REPORT[2]=0;		// ROM POOL SIZE 0
	PID_POOL_REPORT[3]=0;		// ROM EFFECT BLOCK COUNT 0
	PID_POOL_REPORT[4]=2;		//SIMULTANEOUS EFFECT MAX 2
	PID_POOL_REPORT[5]=0b10000000;// DEVICE MANAGED POOL/NO SHARED PARAMETER BLOCKS
	switch(SetupPkt.W_Value.byte.HB) // REPORT TYPE 
	{
	 case 0x01:// INPUT REPORT
	 break;
     case 0x02: // OUTPUT, the host wants to send me the data
	 break;
	 case 0x03:// FEATURE, the host wants ME to send the data
	  //USBEP0SendRAMPtr((BYTE*)&PID_POOL_REPORT, 6, USB_EP0_NO_OPTIONS);
	 break;
	} 
   break;
 }
	
}


/*
void USBCBInitEP(void)
{
    //enable the HID endpoint
    USBEnableEndpoint(HID_EP,USB_IN_ENABLED|USB_OUT_ENABLED|USB_HANDSHAKE_ENABLED|USB_ALLOW_SETUP);
}
*/

void USER_SET_REPORT_HANDLER(void)
{
	switch(SetupPkt.W_Value.byte.LB)  
	  {
		  case 0x10:// REPORT ID 0x10 | Create New Effect Report
					
				   switch(SetupPkt.W_Value.byte.HB) // REPORT TYPE 
				    {
				     case 0x01:// INPUT REPORT
				     break;
				     case 0x02: // OUTPUT, the host wants to send me the data
				     break;
				     case 0x03:// FEATURE, the host wants ME to send the data
						
							USBEP0Receive((BYTE*)&pid_report[0], SetupPkt.wLength, USBSetEffect); 
				     break;
				    } 
		  break;
		}
		
}



//-----------------------USER HARDWARE INITIALIZATION FUNCTIONS / CALLBACKS------
void API_USER_IO_PORT_INITIALIZATION(void)
{
		 ADCON1 |= 0x0F;                 // Default all pins to digital
		// TO BE COMPLETED : INITIALIZATION OF INPUT PORTS / PWM OUTPUT TO MOTORS / ANALOG IN PORTS

		//---------------------------------------ADC SETUP----------------------------------------
		// SETUP RA 0/1/2/ as input pins
		
/*
	SPPCON 	= 0;
	SSPCON1 = 0; 
	
	INTCON	=0x00;
	INTCON2	=0b01110000;
	INTCON3	=0b00000000;
	PIR1	=0b00000000;
	PIR2	=0b00000000;
	PIE1	=0b00000000;
	PIE2	=0b00000000;
	IPR1	=0b00000000;
	IPR2	=0b00000000;
	RCON	=0b10011111;
	*/
	TRISA=0x00;
	TRISB=0x00;
	TRISC=0x00;
	TRISD=0x00;
	TRISE=0x00;

	//---------------------------------------ADC SETUP----------------------------------------
	// SETUP RA 0/1/as input pins

	ADCON1	=0b00001101;// 	AD MODULE : VDD/VSS - [ RA 0/1/ CONFIGURED AS ANALOG / rest is digital]
	ADCON2	=0b10111000;//	AD MODULE: RIGHT JUSTIFIED / 0 / 111=20TAD aquisition time / FOSC/2 CONVERSION CLOCK  
	ADCON0	=0b00000001;// 	AD MODULE IS ON
	OpenADC( ADC_FOSC_32 & ADC_RIGHT_JUST &ADC_20_TAD, 		ADC_CH0 &ADC_INT_OFF&ADC_REF_VDD_VSS , ADC_0ANA&ADC_1ANA );
	Delay10TCYx( 5 ); // Delay for 50TCY
	TRISA	=0b00000011;
	LATA	=0b00000000;// 	clear all
	PORTA	=0b00000000;//	clear all

	//---------------------------------------INTERRUPT SETUP----------------------------------------
/*
 involved registers 
  RCON
� INTCON
� INTCON2
� INTCON3
� PIR1, PIR2
� PIE1, PIE2
� IPR1, IPR2
*/	
// I HAVE SET UP : TIMER 1 / TIMER 3 INTERRUPTS/HIGH PRIORITY
//
//---------------------in progress-OK-under test--------------------------------
INTCONbits.GIE=1;	//Global Interrupt Enable bit
INTCONbits.PEIE=1;	//Peripheral Interrupt Enable bit
INTCONbits.TMR0IE=0;//TMR0 Overflow Interrupt Enable bit
INTCONbits.INT0IE=0;//INT0 External Interrupt Enable bit
INTCONbits.RBIE=0;	//RB Port Change Interrupt Enable bit
INTCONbits.TMR0IF=0;//TMR0 Overflow Interrupt Flag bit
INTCONbits.INT0IF=0;//INT0 External Interrupt Flag bit
INTCONbits.RBIF=0;	//RB Port Change Interrupt Flag bit
//--------------------ok---------------------------------
INTCON2bits.RBPU=0;		//PORTB Pull-up Enable bit
INTCON2bits.INTEDG0=0;	//External Interrupt 0 Edge Select bit
INTCON2bits.INTEDG1=0;	//External Interrupt 1 Edge Select bit
INTCON2bits.INTEDG2=0;	//External Interrupt 2 Edge Select bit
INTCON2bits.TMR0IP=0;	//TMR0 Overflow Interrupt Priority bit
INTCON2bits.RBIP=0;		//RB Port Change Interrupt Priority bit
//---------------------ok--------------------------------
INTCON3bits.INT2IP=0;	//INT2 External Interrupt Priority bit
INTCON3bits.INT1IP=0;	//INT1 External Interrupt Priority bit
INTCON3bits.INT2IE=0;	//INT2 External Interrupt Enable bit
INTCON3bits.INT1IE=0;	//INT1 External Interrupt Enable bit
INTCON3bits.INT2IF=0;	//INT2 External Interrupt Flag bit
INTCON3bits.INT1IF=0;	//INT1 External Interrupt Flag bit
//-----------------------ok------------------------------
PIR1bits.SPPIF=0;	//Streaming Parallel Port Read/Write Interrupt Flag bit(
PIR1bits.ADIF=0;	//A/D Converter Interrupt Flag bit
PIR1bits.RCIF=0;	//EUSART Receive Interrupt Flag bit
PIR1bits.TXIF=0;	//EUSART Transmit Interrupt Flag bit
PIR1bits.SSPIF=0;	//Master Synchronous Serial Port Interrupt Flag bit
PIR1bits.CCP1IF=0;	//CCP1 Interrupt Flag bit
PIR1bits.TMR2IF=0;	//TMR2 to PR2 Match Interrupt Flag bit
PIR1bits.TMR1IF=0;	//TMR1 Overflow Interrupt Flag bit
//----------------------ok-------------------------------
PIR2bits.OSCFIF=0;	//Oscillator Fail Interrupt Flag bit
PIR2bits.CMIF=0;	//Comparator Interrupt Flag bit
PIR2bits.USBIF=0;	//USB Interrupt Flag bit
PIR2bits.EEIF=0;	//Data EEPROM/Flash Write Operation Interrupt Flag bit
PIR2bits.BCLIF=0;	//Bus Collision Interrupt Flag bit
PIR2bits.HLVDIF=0;	//High/Low-Voltage Detect Interrupt Flag bit
PIR2bits.TMR3IF=0;	//TMR3 Overflow Interrupt Flag bit
PIR2bits.CCP2IF=0;	//CCP2 Interrupt Flag bit
//----------------------OK-------------------------------
PIE1bits.SPPIE=0;	//Streaming Parallel Port Read/Write Interrupt Enable bit
PIE1bits.ADIE=0;	//A/D Converter Interrupt Enable bit
PIE1bits.RCIE=0;	//EUSART Receive Interrupt Enable bit
PIE1bits.TXIE=0;	//EUSART Transmit Interrupt Enable bit
PIE1bits.SSPIE=0;	//Master Synchronous Serial Port Interrupt Enable bit
PIE1bits.CCP1IE=0;	//CCP1 Interrupt Enable bit
PIE1bits.TMR2IE=0;	//TMR2 to PR2 Match Interrupt Enable bit
PIE1bits.TMR1IE=1;	//TMR1 Overflow Interrupt Enable bit
//----------------------OK-------------------------------
PIE2bits.OSCFIE=0;	//Oscillator Fail Interrupt Enable bit
PIE2bits.CMIE=0;	//Comparator Interrupt Enable bit
PIE2bits.USBIE=0;	//USB Interrupt Enable bit
PIE2bits.EEIE=0;	//Data EEPROM/Flash Write Operation Interrupt Enable bit
PIE2bits.BCLIE=0;	//Bus Collision Interrupt Enable bit
PIE2bits.HLVDIE=0;	//High/Low-Voltage Detect Interrupt Enable bit
PIE2bits.TMR3IE=1;	//TMR3 Overflow Interrupt Enable bit
PIE2bits.CCP2IE=0;	//CCP2 Interrupt Enable bit
//-------------------------OK----------------------------
IPR1bits.SPPIP=0;	//Streaming Parallel Port Read/Write Interrupt Priority bit
IPR1bits.ADIP=0;	//A/D Converter Interrupt Priority bit
IPR1bits.RCIP=0;	//EUSART Receive Interrupt Priority bit
IPR1bits.TXIP=0;	//EUSART Transmit Interrupt Priority bit
IPR1bits.SSPIP=0;	//Master Synchronous Serial Port Interrupt Priority bit
IPR1bits.CCP1IP=0;	//CCP1 Interrupt Priority bit
IPR1bits.TMR2IP=0;	//TMR2 to PR2 Match Interrupt Priority bit
IPR1bits.TMR1IP=1;	//TMR1 Overflow Interrupt Priority bit
//------------------------OK-----------------------------
IPR2bits.OSCFIP=0;	//Oscillator Fail Interrupt Priority bit
IPR2bits.CMIP=0;	//Comparator Interrupt Priority bit
IPR2bits.USBIP=0;	//USB Interrupt Priority bit
IPR2bits.EEIP=0;	//Data EEPROM/Flash Write Operation Interrupt Priority bit
IPR2bits.BCLIP=0;	//Bus Collision Interrupt Priority bit
IPR2bits.HLVDIP=0;	//High/Low-Voltage Detect Interrupt Priority bit
IPR2bits.TMR3IP=1;	//TMR3 Overflow Interrupt Priority bit
IPR2bits.CCP2IP=0;	//CCP2 Interrupt Priority bit
//----------------------OK-NO TOUCH-------------------------------	
RCONbits.IPEN=1;	//Interrupt Priority Enable bit
//RCONbits.SBOREN=0;	//BOR Software Enable bit
//RCONbits.RI=1;		//RESET Instruction Flag bit
//RCONbits.TO=1;		//Watchdog Time-out Flag bit
//RCONbits.PD=1;		//Power-Down Detection Flag bit
//RCONbits.POR=1;		//Power-on Reset Status bit
//RCONbits.BOR=1;		//Brown-out Reset Status bit
//-----------------------------------------------------	


	//---------------------------------------TIMERS SETUP----------------------------------------
//------------------------OK TIMER 1-----------------------------	
T1CONbits.RD16=1;	//16-Bit Read/Write Mode Enable bit 16bit
T1CONbits.T1RUN=0;	//Timer1 System Clock Status bit
T1CONbits.T1CKPS1=1;//Timer1 Input Clock Prescale Select bits // 1:8 prescaller
T1CONbits.T1CKPS0=1;//Timer1 Input Clock Prescale Select bits
T1CONbits.T1OSCEN=0;//Timer1 Oscillator Enable bit
T1CONbits.T1SYNC=1;	//Timer1 External Clock Input Synchronization Select bit 1=no?
T1CONbits.TMR1CS=0;	//Timer1 Clock Source Select bit 0=internal clock
T1CONbits.TMR1ON=0;	//Timer1 On bit
// RC1/T1OSI/UOE and  RC0/T1OSO/T13CKI pins become inputs by default....
//------------------------OK TIMER 3-----------------------------	
T3CONbits.RD16=1;	//16-Bit Read/Write Mode Enable bit 16bit
T3CONbits.T3CCP2=1;	//Timer3 and Timer1 to CCPx Enable bits
T3CONbits.T3CKPS1=1;//Timer3 Input Clock Prescale Select bits
T3CONbits.T3CKPS0=1;//Timer3 Input Clock Prescale Select bits
T3CONbits.T3CCP1=0;//Timer3 and Timer1 to CCPx Enable bits
T3CONbits.T3SYNC=1;	//Timer3 External Clock Input Synchronization Control bit
T3CONbits.TMR3CS=0;	//Timer3 Clock Source Select bit 0=internal clock
T3CONbits.TMR3ON=0;	//Timer3 On bit

TMR1H=0x00;
TMR1L=0x00;
TMR3H=0x00;
TMR3L=0x00;


}



/********************************************************************
 * Function:        static void API_InitializeSystem(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        API_InitializeSystem is a centralize initialization
 *                  routine. All required USB initialization routines
 *                  are called from here.
 *
 *                  User application initialization routine should
 *                  also be called from here.                  
 *
 * Note:            None
 *******************************************************************/
void API_InitializeSystem(void)
{
	
    USBDeviceInit();	//usb_device.c.  Initializes USB module SFRs and firmware
    					//variables to known states.
	API_USER_IO_PORT_INITIALIZATION();
	CONFIGURED_EFFECT_NUMBER=0x0000;
USBOutHandle = 0;
USBInHandle = 0;
USBEP0OutHandle = 0;
USBEP0InHandle = 0;
//---------------------------new method---------------------
EP1_DATA_RECEIVED_STATUS=0; // indicates when data has been received on EP1 and it's ready to be serviced
EP1_DATA_SERVICED=1; // indicates if the data has been serviced. start at 1 and reset on first read

for(temp_char=0;temp_char<12;temp_char++)
{
	EFFECT_ON_ARRAY[temp_char]=0;
}
}//end InitializeSystem



/*******************************************************************
 * Function:        void USBCBCheckOtherReq(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        When SETUP packets arrive from the host, some
 * 					firmware must process the request and respond
 *					appropriately to fulfill the request.  Some of
 *					the SETUP packets will be for standard
 *					USB "chapter 9" (as in, fulfilling chapter 9 of
 *					the official USB specifications) requests, while
 *					others may be specific to the USB device class
 *					that is being implemented.  For example, a HID
 *					class device needs to be able to respond to
 *					"GET REPORT" type of requests.  This
 *					is not a standard USB chapter 9 request, and 
 *					therefore not handled by usb_device.c.  Instead
 *					this request should be handled by class specific 
 *					firmware, such as that contained in usb_function_hid.c.
 *
 * Note:            None
 *******************************************************************/
void USBCBCheckOtherReq(void)
{
    USBCheckHIDRequest();
}//end






// ******************************************************************************************************
// ************** USB Callback Functions ****************************************************************
// ******************************************************************************************************
// The USB firmware stack will call the callback functions USBCBxxx() in response to certain USB related
// events.  For example, if the host PC is powering down, it will stop sending out Start of Frame (SOF)
// packets to your device.  In response to this, all USB devices are supposed to decrease their power
// consumption from the USB Vbus to <2.5mA each.  The USB module detects this condition (which according
// to the USB specifications is 3+ms of no bus activity/SOF packets) and then calls the USBCBSuspend()
// function.  You should modify these callback functions to take appropriate actions for each of these
// conditions.  For example, in the USBCBSuspend(), you may wish to add code that will decrease power
// consumption from Vbus to <2.5mA (such as by clock switching, turning off LEDs, putting the
// microcontroller to sleep, etc.).  Then, in the USBCBWakeFromSuspend() function, you may then wish to
// add code that undoes the power saving things done in the USBCBSuspend() function.

// The USBCBSendResume() function is special, in that the USB stack will not automatically call this
// function.  This function is meant to be called from the application firmware instead.  See the
// additional comments near the function.

/******************************************************************************
 * Function:        void USBCBSuspend(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Call back that is invoked when a USB suspend is detected
 *
 * Note:            None
 *****************************************************************************/
void USBCBSuspend(void)
{
	//Example power saving code.  Insert appropriate code here for the desired
	//application behavior.  If the microcontroller will be put to sleep, a
	//process similar to that shown below may be used:
	
	//ConfigureIOPinsForLowPower();
	//SaveStateOfAllInterruptEnableBits();
	//DisableAllInterruptEnableBits();
	//EnableOnlyTheInterruptsWhichWillBeUsedToWakeTheMicro();	//should enable at least USBActivityIF as a wake source
	//Sleep();
	//RestoreStateOfAllPreviouslySavedInterruptEnableBits();	//Preferrably, this should be done in the USBCBWakeFromSuspend() function instead.
	//RestoreIOPinsToNormal();									//Preferrably, this should be done in the USBCBWakeFromSuspend() function instead.

	//IMPORTANT NOTE: Do not clear the USBActivityIF (ACTVIF) bit here.  This bit is 
	//cleared inside the usb_device.c file.  Clearing USBActivityIF here will cause 
	//things to not work as intended.	
	

    #if defined(__C30__)
    #if 0
        U1EIR = 0xFFFF;
        U1IR = 0xFFFF;
        U1OTGIR = 0xFFFF;
        IFS5bits.USB1IF = 0;
        IEC5bits.USB1IE = 1;
        U1OTGIEbits.ACTVIE = 1;
        U1OTGIRbits.ACTVIF = 1;
        Sleep();
    #endif
    #endif
}


/******************************************************************************
 * Function:        void _USB1Interrupt(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called when the USB interrupt bit is set
 *					In this example the interrupt is only used when the device
 *					goes to sleep when it receives a USB suspend command
 *
 * Note:            None
 *****************************************************************************/
#if 0
void __attribute__ ((interrupt)) _USB1Interrupt(void)
{
    #if !defined(self_powered)
        if(U1OTGIRbits.ACTVIF)
        {       
            IEC5bits.USB1IE = 0;
            U1OTGIEbits.ACTVIE = 0;
            IFS5bits.USB1IF = 0;
        
            //USBClearInterruptFlag(USBActivityIFReg,USBActivityIFBitNum);
            USBClearInterruptFlag(USBIdleIFReg,USBIdleIFBitNum);
            //USBSuspendControl = 0;
        }
    #endif
}
#endif

/******************************************************************************
 * Function:        void USBCBWakeFromSuspend(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The host may put USB peripheral devices in low power
 *					suspend mode (by "sending" 3+ms of idle).  Once in suspend
 *					mode, the host may wake the device back up by sending non-
 *					idle state signalling.
 *					
 *					This call back is invoked when a wakeup from USB suspend 
 *					is detected.
 *
 * Note:            None
 *****************************************************************************/
void USBCBWakeFromSuspend(void)
{
	// If clock switching or other power savings measures were taken when
	// executing the USBCBSuspend() function, now would be a good time to
	// switch back to normal full power run mode conditions.  The host allows
	// a few milliseconds of wakeup time, after which the device must be 
	// fully back to normal, and capable of receiving and processing USB
	// packets.  In order to do this, the USB module must receive proper
	// clocking (IE: 48MHz clock must be available to SIE for full speed USB
	// operation).
}

/********************************************************************
 * Function:        void USBCB_SOF_Handler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USB host sends out a SOF packet to full-speed
 *                  devices every 1 ms. This interrupt may be useful
 *                  for isochronous pipes. End designers should
 *                  implement callback routine as necessary.
 *
 * Note:            None
 *******************************************************************/
void USBCB_SOF_Handler(void)
{
    // No need to clear UIRbits.SOFIF to 0 here.
    // Callback caller is already doing that.
}

/*******************************************************************
 * Function:        void USBCBErrorHandler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The purpose of this callback is mainly for
 *                  debugging during development. Check UEIR to see
 *                  which error causes the interrupt.
 *
 * Note:            None
 *******************************************************************/
void USBCBErrorHandler(void)
{
    // No need to clear UEIR to 0 here.
    // Callback caller is already doing that.

	// Typically, user firmware does not need to do anything special
	// if a USB error occurs.  For example, if the host sends an OUT
	// packet to your device, but the packet gets corrupted (ex:
	// because of a bad connection, or the user unplugs the
	// USB cable during the transmission) this will typically set
	// one or more USB error interrupt flags.  Nothing specific
	// needs to be done however, since the SIE will automatically
	// send a "NAK" packet to the host.  In response to this, the
	// host will normally retry to send the packet again, and no
	// data loss occurs.  The system will typically recover
	// automatically, without the need for application firmware
	// intervention.
	
	// Nevertheless, this callback function is provided, such as
	// for debugging purposes.
}




/*******************************************************************
 * Function:        void USBCBStdSetDscHandler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USBCBStdSetDscHandler() callback function is
 *					called when a SETUP, bRequest: SET_DESCRIPTOR request
 *					arrives.  Typically SET_DESCRIPTOR requests are
 *					not used in most applications, and it is
 *					optional to support this type of request.
 *
 * Note:            None
 *******************************************************************/
void USBCBStdSetDscHandler(void)
{
    // Must claim session ownership if supporting this request
}//end


/*******************************************************************
 * Function:        void USBCBInitEP(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called when the device becomes
 *                  initialized, which occurs after the host sends a
 * 					SET_CONFIGURATION (wValue not = 0) request.  This 
 *					callback function should initialize the endpoints 
 *					for the device's usage according to the current 
 *					configuration.
 *
 * Note:            None
 *******************************************************************/
void USBCBInitEP(void)
{
    //enable the HID endpoint
    USBEnableEndpoint(HID_EP,USB_OUT_ENABLED|USB_IN_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
    USBEnableEndpoint(_EP_OUT,USB_OUT_ENABLED|USB_IN_ENABLED|USB_HANDSHAKE_ENABLED|USB_ALLOW_SETUP);
}

/********************************************************************
 * Function:        void USBCBSendResume(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USB specifications allow some types of USB
 * 					peripheral devices to wake up a host PC (such
 *					as if it is in a low power suspend to RAM state).
 *					This can be a very useful feature in some
 *					USB applications, such as an Infrared remote
 *					control	receiver.  If a user presses the "power"
 *					button on a remote control, it is nice that the
 *					IR receiver can detect this signalling, and then
 *					send a USB "command" to the PC to wake up.
 *					
 *					The USBCBSendResume() "callback" function is used
 *					to send this special USB signalling which wakes 
 *					up the PC.  This function may be called by
 *					application firmware to wake up the PC.  This
 *					function should only be called when:
 *					
 *					1.  The USB driver used on the host PC supports
 *						the remote wakeup capability.
 *					2.  The USB configuration descriptor indicates
 *						the device is remote wakeup capable in the
 *						bmAttributes field.
 *					3.  The USB host PC is currently sleeping,
 *						and has previously sent your device a SET 
 *						FEATURE setup packet which "armed" the
 *						remote wakeup capability.   
 *
 *					This callback should send a RESUME signal that
 *                  has the period of 1-15ms.
 *
 * Note:            Interrupt vs. Polling
 *                  -Primary clock
 *                  -Secondary clock ***** MAKE NOTES ABOUT THIS *******
 *                   > Can switch to primary first by calling USBCBWakeFromSuspend()
 
 *                  The modifiable section in this routine should be changed
 *                  to meet the application needs. Current implementation
 *                  temporary blocks other functions from executing for a
 *                  period of 1-13 ms depending on the core frequency.
 *
 *                  According to USB 2.0 specification section 7.1.7.7,
 *                  "The remote wakeup device must hold the resume signaling
 *                  for at lest 1 ms but for no more than 15 ms."
 *                  The idea here is to use a delay counter loop, using a
 *                  common value that would work over a wide range of core
 *                  frequencies.
 *                  That value selected is 1800. See table below:
 *                  ==========================================================
 *                  Core Freq(MHz)      MIP         RESUME Signal Period (ms)
 *                  ==========================================================
 *                      48              12          1.05
 *                       4              1           12.6
 *                  ==========================================================
 *                  * These timing could be incorrect when using code
 *                    optimization or extended instruction mode,
 *                    or when having other interrupts enabled.
 *                    Make sure to verify using the MPLAB SIM's Stopwatch
 *                    and verify the actual signal on an oscilloscope.
 *******************************************************************/
void USBCBSendResume(void)
{
    /*static*/ WORD delay_count;
    
    USBResumeControl = 1;                // Start RESUME signaling
    
    delay_count = 1800U;                // Set RESUME line for 1-13 ms
    do
    {
        delay_count--;
    }while(delay_count);
    USBResumeControl = 0;
}


/*******************************************************************
 * Function:        BOOL USER_USB_CALLBACK_EVENT_HANDLER(
 *                        USB_EVENT event, void *pdata, WORD size)
 *
 * PreCondition:    None
 *
 * Input:           USB_EVENT event - the type of event
 *                  void *pdata - pointer to the event data
 *                  WORD size - size of the event data
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called from the USB stack to
 *                  notify a user application that a USB event
 *                  occured.  This callback is in interrupt context
 *                  when the USB_INTERRUPT option is selected.
 *
 * Note:            None
 *******************************************************************/
BOOL USER_USB_CALLBACK_EVENT_HANDLER(USB_EVENT event, void *pdata, WORD size)
{
    switch(event)
    {
        case EVENT_CONFIGURED: 
            USBCBInitEP();
            break;
        case EVENT_SET_DESCRIPTOR:
            USBCBStdSetDscHandler();
            break;
        case EVENT_EP0_REQUEST:
            USBCBCheckOtherReq();
            break;
        case EVENT_SOF:
            USBCB_SOF_Handler();
            break;
        case EVENT_SUSPEND:
            USBCBSuspend();
            break;
        case EVENT_RESUME:
            USBCBWakeFromSuspend();
            break;
        case EVENT_BUS_ERROR:
            USBCBErrorHandler();
            break;
        case EVENT_TRANSFER:
            Nop();
            break;
        default:
            break;
    }      
    return TRUE; 
}

