/********************************************************************
 FileName:     	usb_descriptors.c
 Dependencies:	See INCLUDES section
 Processor:		PIC18 or PIC24 USB Microcontrollers
 Hardware:		The code is natively intended to be used on the following
 				hardware platforms: PICDEM� FS USB Demo Board, 
 				PIC18F87J50 FS USB Plug-In Module, or
 				Explorer 16 + PIC24 USB PIM.  The firmware may be
 				modified for use on other USB platforms by editing the
 				HardwareProfile.h file.
 Complier:  	Microchip C18 (for PIC18) or C30 (for PIC24)
 Company:		Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the �Company�) for its PIC� Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively on Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

*********************************************************************
-usb_descriptors.c-
-------------------------------------------------------------------
Filling in the descriptor values in the usb_descriptors.c file:
-------------------------------------------------------------------

[Device Descriptors]
The device descriptor is defined as a USB_DEVICE_DESCRIPTOR type.  
This type is defined in usb_ch9.h  Each entry into this structure
needs to be the correct length for the data type of the entry.

[Configuration Descriptors]
The configuration descriptor was changed in v2.x from a structure
to a BYTE array.  Given that the configuration is now a byte array
each byte of multi-byte fields must be listed individually.  This
means that for fields like the total size of the configuration where
the field is a 16-bit value "64,0," is the correct entry for a
configuration that is only 64 bytes long and not "64," which is one
too few bytes.

The configuration attribute must always have the _DEFAULT
definition at the minimum. Additional options can be ORed
to the _DEFAULT attribute. Available options are _SELF and _RWU.
These definitions are defined in the usb_device.h file. The
_SELF tells the USB host that this device is self-powered. The
_RWU tells the USB host that this device supports Remote Wakeup.

[Endpoint Descriptors]
Like the configuration descriptor, the endpoint descriptors were 
changed in v2.x of the stack from a structure to a BYTE array.  As
endpoint descriptors also has a field that are multi-byte entities,
please be sure to specify both bytes of the field.  For example, for
the endpoint size an endpoint that is 64 bytes needs to have the size
defined as "64,0," instead of "64,"

Take the following example:
    // Endpoint Descriptor //
    0x07,                       //the size of this descriptor //
    USB_DESCRIPTOR_ENDPOINT,    //Endpoint Descriptor
    _EP02_IN,                   //EndpointAddress
    _INT,                       //Attributes
    0x08,0x00,                  //size (note: 2 bytes)
    0x02,                       //Interval

The first two parameters are self-explanatory. They specify the
length of this endpoint descriptor (7) and the descriptor type.
The next parameter identifies the endpoint, the definitions are
defined in usb_device.h and has the following naming
convention:
_EP<##>_<dir>
where ## is the endpoint number and dir is the direction of
transfer. The dir has the value of either 'OUT' or 'IN'.
The next parameter identifies the type of the endpoint. Available
options are _BULK, _INT, _ISO, and _CTRL. The _CTRL is not
typically used because the default control transfer endpoint is
not defined in the USB descriptors. When _ISO option is used,
addition options can be ORed to _ISO. Example:
_ISO|_AD|_FE
This describes the endpoint as an isochronous pipe with adaptive
and feedback attributes. See usb_device.h and the USB
specification for details. The next parameter defines the size of
the endpoint. The last parameter in the polling interval.

-------------------------------------------------------------------
Adding a USB String
-------------------------------------------------------------------
A string descriptor array should have the following format:

rom struct{byte bLength;byte bDscType;word string[size];}sdxxx={
sizeof(sdxxx),DSC_STR,<text>};

The above structure provides a means for the C compiler to
calculate the length of string descriptor sdxxx, where xxx is the
index number. The first two bytes of the descriptor are descriptor
length and type. The rest <text> are string texts which must be
in the unicode format. The unicode format is achieved by declaring
each character as a word type. The whole text string is declared
as a word array with the number of characters equals to <size>.
<size> has to be manually counted and entered into the array
declaration. Let's study this through an example:
if the string is "USB" , then the string descriptor should be:
(Using index 02)
rom struct{byte bLength;byte bDscType;word string[3];}sd002={
sizeof(sd002),DSC_STR,'U','S','B'};

A USB project may have multiple strings and the firmware supports
the management of multiple strings through a look-up table.
The look-up table is defined as:
rom const unsigned char *rom USB_SD_Ptr[]={&sd000,&sd001,&sd002};

The above declaration has 3 strings, sd000, sd001, and sd002.
Strings can be removed or added. sd000 is a specialized string
descriptor. It defines the language code, usually this is
US English (0x0409). The index of the string must match the index
position of the USB_SD_Ptr array, &sd000 must be in position
USB_SD_Ptr[0], &sd001 must be in position USB_SD_Ptr[1] and so on.
The look-up table USB_SD_Ptr is used by the get string handler
function.

-------------------------------------------------------------------

The look-up table scheme also applies to the configuration
descriptor. A USB device may have multiple configuration
descriptors, i.e. CFG01, CFG02, etc. To add a configuration
descriptor, user must implement a structure similar to CFG01.
The next step is to add the configuration descriptor name, i.e.
cfg01, cfg02,.., to the look-up table USB_CD_Ptr. USB_CD_Ptr[0]
is a dummy place holder since configuration 0 is the un-configured
state according to the definition in the USB specification.

********************************************************************/
 
/*********************************************************************
 * Descriptor specific type definitions are defined in:
 * usb_device.h
 *
 * Configuration options are defined in:
 * usb_config.h
 ********************************************************************/
#ifndef __USB_DESCRIPTORS_C
#define __USB_DESCRIPTORS_C

/** INCLUDES *******************************************************/
#include "usb.h"
#include "usb_function_hid.h"

/** CONSTANTS ******************************************************/
#if defined(__18CXX)
#pragma romdata
#endif

/* Device Descriptor */
ROM USB_DEVICE_DESCRIPTOR device_dsc=
{
    0x12,    // Size of this descriptor in bytes
    USB_DESCRIPTOR_DEVICE,                // DEVICE descriptor type
    0x0200,                 // USB Spec Release Number in BCD format
    0x00,                   // Class Code
    0x00,                   // Subclass code
    0x00,                   // Protocol code
    USB_EP0_BUFF_SIZE,      // Max packet size for EP0, see usb_config.h
    MY_VID,                 // Vendor ID, see usb_config.h
    MY_PID,                 // Product ID, see usb_config.h
    0x0001,                 // Device release number in BCD format
    0x01,                   // Manufacturer string index
    0x02,                   // Product string index
    0x00,                   // Device serial number string index
    0x01                    // Number of possible configurations
};

/* Configuration 1 Descriptor */
ROM BYTE configDescriptor1[]={
    /* Configuration Descriptor */
    0x09,//sizeof(USB_CFG_DSC),    // Size of this descriptor in bytes
    USB_DESCRIPTOR_CONFIGURATION,                // CONFIGURATION descriptor type
    DESC_CONFIG_WORD(0x0029),   // Total length of data for this cfg
    1,                      // Number of interfaces in this cfg
    1,                      // Index value of this configuration
    0,                      // Configuration string index
    _DEFAULT | _SELF,               // Attributes, see usb_device.h
    120,                     // Max power consumption (2X mA)

    /* Interface Descriptor */
    0x09,//sizeof(USB_INTF_DSC),   // Size of this descriptor in bytes
    USB_DESCRIPTOR_INTERFACE,               // INTERFACE descriptor type
    0,                      // Interface Number
    0,                      // Alternate Setting Number
    2,                      // Number of endpoints in this intf
    HID_INTF,               // Class code
    0,     // Subclass code
    0,     // Protocol code
    0,                      // Interface string index

    /* HID Class-Specific Descriptor */
    0x09,//sizeof(USB_HID_DSC)+3,    // Size of this descriptor in bytes RRoj hack
    DSC_HID,                // HID descriptor type
    DESC_CONFIG_WORD(0x0111),                 // HID Spec Release Number in BCD format (1.11)
    0x00,                   // Country Code (0x00 for Not supported)
    HID_NUM_OF_DSC,         // Number of class descriptors, see usbcfg.h
    DSC_RPT,                // Report descriptor type
    DESC_CONFIG_WORD(HID_RPT01_SIZE),   //sizeof(hid_rpt01),      // Size of the report descriptor
    
    /* Endpoint Descriptor */
    0x07,/*sizeof(USB_EP_DSC)*/
    USB_DESCRIPTOR_ENDPOINT,    //Endpoint Descriptor
    HID_EP | _EP_IN,            //EndpointAddress
    _INTERRUPT,                       //Attributes
    DESC_CONFIG_WORD(64),        //size
    0x01,                        //Interval

    /* Endpoint Descriptor */
    0x07,/*sizeof(USB_EP_DSC)*/
    USB_DESCRIPTOR_ENDPOINT,    //Endpoint Descriptor
    HID_EP | _EP_OUT,            //EndpointAddress
    _INTERRUPT,                       //Attributes
    DESC_CONFIG_WORD(64),        //size
    0x01                        //Interval
};


//Language code string descriptor
ROM struct{BYTE bLength;BYTE bDscType;WORD string[1];}sd000={
sizeof(sd000),USB_DESCRIPTOR_STRING,{0x0409
}};

//Manufacturer string descriptor
ROM struct{BYTE bLength;BYTE bDscType;WORD string[25];}sd001={
sizeof(sd001),USB_DESCRIPTOR_STRING,
{'C','O','M','A','N',' ',' ',' ',' ',' ',
'N','U','T','U',' ',' ','V','1','3','R',' ',' ',' ',' ','.'
}};

//Product string descriptor
ROM struct{BYTE bLength;BYTE bDscType;WORD string[24];}sd002={
sizeof(sd002),USB_DESCRIPTOR_STRING,
{'C','O','M','A','N',' ','N','U','T','U',' ','V','1','3','R'
}};

//Array of configuration descriptors
ROM BYTE *ROM USB_CD_Ptr[]=
{
    (ROM BYTE *ROM)&configDescriptor1
};

//Array of string descriptors
ROM BYTE *ROM USB_SD_Ptr[]=
{
    (ROM BYTE *ROM)&sd000,
    (ROM BYTE *ROM)&sd001,
    (ROM BYTE *ROM)&sd002
};

ROM struct{BYTE report[HID_RPT01_SIZE];}hid_rpt01={{

 0x05,0x01, // Usage Page Generic Desktop
 0x09,0x04, // Usage Joystick
 0xA1,0x01, // Collection Application
    0x85,0x01, // Report ID 1
			0x05,0x09, // [0x03]USAGE PAGE (BUTTON)
			0x19,0x01, // [0x04]USAGE_MINIMUM(BUTTON 1)
			0x29,0x10, // [0x05]USAGE_MAXIMUM(BUTTON 16)
			0x15,0x00, // [0x06]LOGICAL_MINIMUM
			0x25,0x01, // [0x07]LOGICAL_MAXIMUM
			0x35,0x00, // [0x08]PHYSICAL_MINIMUM
			0x45,0x01, // [0x09]PHYSICAL_MAXIMUM
			0x75,0x01, // [0x0A]REPORT_SIZE
			0x95,0x10, // [0x0B]REPORT_COUNT
			0x81,0x02, // [0x0C]INPUT
			0x05,0x01, // [0x0D]USAGE PAGE (GENERIC DESKTOP CONTROLS)
			0x09,0x39, // [0x0E]USAGE(HAT_SWITCH)
				0x15,0x00, // [0x0F]LOGICAL_MINIMUM
				0x25,0x07, // [0x10]LOGICAL_MAXIMUM
				0x35,0x00, // [0x11]PHYSICAL_MINIMUM
				0x46,0x3B,0x01, // [0x12]PHYSICAL_MAXIMUM
				0x65,0x14, // [0x13]UNIT
				0x75,0x04, // [0x14]REPORT_SIZE
				0x95,0x01, // [0x15]REPORT_COUNT
			0x81,0x42, // [0x16]INPUT
				0x65,0x00, // [0x17]UNIT
				0x95,0x01, // [0x18]REPORT_COUNT
			0x81,0x01, // [0x19]INPUT
			0x09,0x30, // [0x1A]USAGE(X)
			0x09,0x31, // [0x1B]USAGE(Y)
			0x09,0x32, // [0x1C]USAGE(Z)
			0x09,0x33, // [0x1D]USAGE(Rx)
				0x15,0x00, // [0x1E]LOGICAL_MINIMUM
				0x26,0x00,0x04, // [0x1F]LOGICAL_MAXIMUM
				0x35,0x00, // [0x20]PHYSICAL_MINIMUM
				0x46,0x00,0x04, // [0x21]PHYSICAL_MAXIMUM
				0x75,0x10, // [0x22]REPORT_SIZE
				0x95,0x04, // [0x23]REPORT_COUNT
			0x81,0x02, // [0x24]INPUT
    

 
 /*
  Input
  Collection Datalink (sub-collection)
  Physical Interface (Usage: PID State report)
  ID: 2
  state report: 5X1bit
  Padding: 3bit
  PID Device Control: 1bit
  Effect Block Index: 7bit 
 */



    0x05,0x0F, // Usage Page Physical Interface
    0x09,0x92, // Usage PID State report 
	    0xA1,0x02, // Collection Datalink (logical)
	
	       0x85,0x02, // Report ID 2
	       0x09,0x9F, // Usage Device is Pause 
	       0x09,0xA0, // Usage Actuators Enabled
	       0x09,0xA4, // Usage Safety Switch
	       0x09,0xA5, // Usage Actuator Override Switch
	       0x09,0xA6, // Usage Actuator Power
	       0x15,0x00, // Logical Minimum 0
	       0x25,0x01, // Logical Maximum 1
	       0x35,0x00, // Physical Minimum 0
	       0x45,0x01, // Physical Maximum 1
	       0x75,0x01, // Report Size 1
	       0x95,0x05, // Report Count 5
	       0x81,0x02, // Input (Variable)
	       0x95,0x03, // Report Count 3
	       0x81,0x03, // Input (Constant, Variable)
	
	
	       0x09,0x94, // Usage Effect Playing
	       0x15,0x00, // Logical Minimum 0
	       0x25,0x01, // Logical Maximum 1
	       0x35,0x00, // Physical Minimum 0
	       0x45,0x01, // Physical Maximum 1
	       0x75,0x01, // Report Size 1
	       0x95,0x01, // Report Count 1
	       0x81,0x02, // Input (Variable)
	       0x09,0x22, // Usage Effect Block Index
	       0x15,0x01, // Logical Minimum 1
	       0x25,0x28, // Logical Maximum 28h (40d)
	       0x35,0x01, // Physical Minimum 1
	       0x45,0x28, // Physical Maximum 28h (40d)
	       0x75,0x07, // Report Size 7
	       0x95,0x01, // Report Count 1
	       0x81,0x02, // Input (Variable)
	    0xC0 , // End Collection
 
 /*
  Output
  Collection Datalink:
  Usage Set Effect Report
  
  ID:1
  Effect Block Index: 8bit
  
  subcollection Effect Type
  12 effect types, 8bit each

 */
    0x09,0x21, // Usage Set Effect Report
    0xA1,0x02, // Collection Datalink (Logical)
		    	0x85,0x03, // Report ID 3
		
		       0x09,0x22, // Usage Effect Block Index
		       0x15,0x01, // Logical Minimum 1
		       0x25,0x28, // Logical Maximum 28h (40d)
		       0x35,0x01, // Physical Minimum 1
		       0x45,0x28, // Physical Maximum 28h (40d)
		       0x75,0x08, // Report Size 8
		       0x95,0x01, // Report Count 1
		       0x91,0x02, // Output (Variable)
		
		       0x09,0x25, // Usage Effect Type
		       0xA1,0x02, // Collection Datalink
		          0x09,0x26, // Usage ET Constant Force
		          0x09,0x27, // Usage ET Ramp
		          0x09,0x30, // Usage ET Square
		          0x09,0x31, // Usage ET Sine
		          0x09,0x32, // Usage ET Triangle
		          0x09,0x33, // Usage ET Sawtooth Up
		          0x09,0x34, // Usage ET Sawtooth Down
		          0x09,0x40, // Usage ET Spring
		          0x09,0x41, // Usage ET Damper
		          0x09,0x42, // Usage ET Inertia
		          0x09,0x43, // Usage ET Friction
		          0x09,0x28, // Usage ET Custom Force Data
		          0x25,0x0C, // Logical Maximum Ch (12d)
		          0x15,0x01, // Logical Minimum 1
		          0x35,0x01, // Physical Minimum 1
		          0x45,0x0C, // Physical Maximum Ch (12d)
		          0x75,0x08, // Report Size 8
		          0x95,0x01, // Report Count 1
		          0x91,0x00, // Output
		
		       0xC0 , // End Collection

       0x09,0x50, // Usage Duration
       0x09,0x54, // Usage Trigger Repeat Interval
       0x09,0x51, // Usage Sample Period
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x7F, // Logical Maximum 7FFFh (32767d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x7F, // Physical Maximum 7FFFh (32767d)
       0x66,0x03,0x10, // Unit 1003h (4099d)
       0x55,0xFD, // Unit Exponent FDh (253d)
       0x75,0x10, // Report Size 10h (16d)
       0x95,0x03, // Report Count 3
       0x91,0x02, // Output (Variable)

       0x55,0x00, // Unit Exponent 0
       0x66,0x00,0x00, // Unit 0
       0x09,0x52, // Usage Gain
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x35,0x00, // Physical Minimum 0
       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)

       0x09,0x53, // Usage Trigger Button
       0x15,0x01, // Logical Minimum 1
       0x25,0x08, // Logical Maximum 8
       0x35,0x01, // Physical Minimum 1
       0x45,0x08, // Physical Maximum 8
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)

		       0x09,0x55, // Usage Axes Enable
		       0xA1,0x02, // Collection Datalink
		          0x05,0x01, // Usage Page Generic Desktop
		          0x09,0x30, // Usage X
		          0x09,0x31, // Usage Y
		          0x15,0x00, // Logical Minimum 0
		          0x25,0x01, // Logical Maximum 1
		          0x75,0x01, // Report Size 1
		          0x95,0x02, // Report Count 2
		          0x91,0x02, // Output (Variable)
		       0xC0 , // End Collection

       0x05,0x0F, // Usage Page Physical Interface
       0x09,0x57, // Usage Direction Enable
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)

       0x95,0x05, // Report Count 5
       0x91,0x03, // Output (Constant, Variable)

		       0x09,0x57, // Usage Direction
		       0xA1,0x02, // Collection Datalink
		          0x0B,0x01,0x00,0x0A,0x00, // Usage Ordinals: Instance 1
		          0x0B,0x02,0x00,0x0A,0x00, // Usage Ordinals: Instance 2
		          0x66,0x14,0x00, // Unit 14h (20d)
		          0x55,0xFE, // Unit Exponent FEh (254d)
		          0x15,0x00, // Logical Minimum 0
		          0x26,0xFF,0x00, // Logical Maximum FFh (255d)
		          0x35,0x00, // Physical Minimum 0
		          0x47,0xA0,0x8C,0x00,0x00, // Physical Maximum 8CA0h (36000d)
		          0x66,0x00,0x00, // Unit 0
		          0x75,0x08, // Report Size 8
		          0x95,0x02, // Report Count 2
		          0x91,0x02, // Output (Variable)
		          0x55,0x00, // Unit Exponent 0
		          0x66,0x00,0x00, // Unit 0
		       0xC0 , // End Collection

       0x05,0x0F, // Usage Page Physical Interface
       0x09,0xA7, // Usage Undefined
       0x66,0x03,0x10, // Unit 1003h (4099d)
       0x55,0xFD, // Unit Exponent FDh (253d)
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x7F, // Logical Maximum 7FFFh (32767d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x7F, // Physical Maximum 7FFFh (32767d)
       0x75,0x10, // Report Size 10h (16d)
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x66,0x00,0x00, // Unit 0
       0x55,0x00, // Unit Exponent 0
    0xC0 , // End Collection/ Usage Set Effect Report

    0x05,0x0F, // Usage Page Physical Interface
    0x09,0x5A, // Usage Set Envelope Report
    0xA1,0x02, // Collection Datalink

       0x85,0x04, // Report ID 0x04 Usage Set Envelope Report

       0x09,0x22, // Usage Effect Block Index
       0x15,0x01, // Logical Minimum 1
       0x25,0x28, // Logical Maximum 28h (40d)
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x5B, // Usage Attack Level
       0x09,0x5D, // Usage Fade Level
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x35,0x00, // Physical Minimum 0
       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
       0x95,0x02, // Report Count 2
       0x91,0x02, // Output (Variable)
       0x09,0x5C, // Usage Attack Time
       0x09,0x5E, // Usage Fade Time
       0x66,0x03,0x10, // Unit 1003h (4099d)
       0x55,0xFD, // Unit Exponent FDh (253d)
       0x26,0xFF,0x7F, // Logical Maximum 7FFFh (32767d)
       0x46,0xFF,0x7F, // Physical Maximum 7FFFh (32767d)
       0x75,0x10, // Report Size 10h (16d)
       0x91,0x02, // Output (Variable)
       0x45,0x00, // Physical Maximum 0
       0x66,0x00,0x00, // Unit 0
       0x55,0x00, // Unit Exponent 0
    0xC0 , // End Collection

    0x09,0x5F, // Usage Set Condition Report
    0xA1,0x02, // Collection Datalink
			       0x85,0x05, // Report ID 5
			       0x09,0x22, // Usage Effect Block Index
			       0x15,0x01, // Logical Minimum 1
			       0x25,0x28, // Logical Maximum 28h (40d)
			       0x35,0x01, // Physical Minimum 1
			       0x45,0x28, // Physical Maximum 28h (40d)
			       0x75,0x08, // Report Size 8
			       0x95,0x01, // Report Count 1
			       0x91,0x02, // Output (Variable)
			       0x09,0x23, // Usage Parameter Block Offset
			       0x15,0x00, // Logical Minimum 0
			       0x25,0x01, // Logical Maximum 1
			       0x35,0x00, // Physical Minimum 0
			       0x45,0x01, // Physical Maximum 1
			       0x75,0x04, // Report Size 4
			       0x95,0x01, // Report Count 1
			       0x91,0x02, // Output (Variable)
			    0x09,0x58, // Usage Type Specific Block Off...
		       	0xA1,0x02, // Collection Datalink
		          0x0B,0x01,0x00,0x0A,0x00, // Usage Ordinals: Instance 1
		          0x0B,0x02,0x00,0x0A,0x00, // Usage Ordinals: Instance 2
		          0x75,0x02, // Report Size 2
		          0x95,0x02, // Report Count 2
		          0x91,0x02, // Output (Variable)
				0xC0 , // End Collection
	       0x15,0x80, // Logical Minimum 80h (-128d)
	       0x25,0x7F, // Logical Maximum 7Fh (127d)
	       0x36,0xF0,0xD8, // Physical Minimum D8F0h (-10000d)
	       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
	       0x09,0x60, // Usage CP Offset
	       0x75,0x08, // Report Size 8
	       0x95,0x01, // Report Count 1
	       0x91,0x02, // Output (Variable)
	       0x36,0xF0,0xD8, // Physical Minimum D8F0h (-10000d)
	       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
	       0x09,0x61, // Usage Positive Coefficient
	       0x09,0x62, // Usage Negative Coefficient
	       0x95,0x02, // Report Count 2
	       0x91,0x02, // Output (Variable)
	       0x15,0x00, // Logical Minimum 0
	       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
	       0x35,0x00, // Physical Minimum 0
	       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
	       0x09,0x63, // Usage Positive Saturation
	       0x09,0x64, // Usage Negative Saturation
	       0x75,0x08, // Report Size 8
	       0x95,0x02, // Report Count 2
	       0x91,0x02, // Output (Variable)
	       0x09,0x65, // Usage Dead Band
	       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
	       0x95,0x01, // Report Count 1
	       0x91,0x02, // Output (Variable)
    0xC0 , // End Collection


    0x09,0x6E, // Usage Set Periodic Report
    0xA1,0x02, // Collection Datalink
       0x85,0x06, // Report ID 6
       0x09,0x22, // Usage Effect Block Index
       0x15,0x01, // Logical Minimum 1
       0x25,0x28, // Logical Maximum 28h (40d)
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x70, // Usage Magnitude
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x35,0x00, // Physical Minimum 0
       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x6F, // Usage Offset
       0x15,0x80, // Logical Minimum 80h (-128d)
       0x25,0x7F, // Logical Maximum 7Fh (127d)
       0x36,0xF0,0xD8, // Physical Minimum D8F0h (-10000d)
       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x71, // Usage Phase
       0x66,0x14,0x00, // Unit 14h (20d)
       0x55,0xFE, // Unit Exponent FEh (254d)
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x35,0x00, // Physical Minimum 0
       0x47,0xA0,0x8C,0x00,0x00, // Physical Maximum 8CA0h (36000d)
       0x91,0x02, // Output (Variable)
       0x09,0x72, // Usage Period
       0x26,0xFF,0x7F, // Logical Maximum 7FFFh (32767d)
       0x46,0xFF,0x7F, // Physical Maximum 7FFFh (32767d)
       0x66,0x03,0x10, // Unit 1003h (4099d)
       0x55,0xFD, // Unit Exponent FDh (253d)
       0x75,0x10, // Report Size 10h (16d)
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x66,0x00,0x00, // Unit 0
       0x55,0x00, // Unit Exponent 0
    0xC0 , // End Collection


    0x09,0x73, // Usage Set Constant Force Rep...
    0xA1,0x02, // Collection Datalink
       0x85,0x07, // Report ID 7
       0x09,0x22, // Usage Effect Block Index
       0x15,0x01, // Logical Minimum 1
       0x25,0x28, // Logical Maximum 28h (40d)
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x70, // Usage Magnitude
       0x16,0x01,0xFF, // Logical Minimum FF01h (-255d)
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x36,0xF0,0xD8, // Physical Minimum D8F0h (-10000d)
       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
       0x75,0x10, // Report Size 10h (16d)
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
    0xC0 , // End Collection


    0x09,0x74, // Usage Set Ramp Force Report
    0xA1,0x02, // Collection Datalink
       0x85,0x08, // Report ID 8
       0x09,0x22, // Usage Effect Block Index
       0x15,0x01, // Logical Minimum 1
       0x25,0x28, // Logical Maximum 28h (40d)
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x75, // Usage Ramp Start
       0x09,0x76, // Usage Ramp End
       0x15,0x80, // Logical Minimum 80h (-128d)
       0x25,0x7F, // Logical Maximum 7Fh (127d)
       0x36,0xF0,0xD8, // Physical Minimum D8F0h (-10000d)
       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
       0x75,0x08, // Report Size 8
       0x95,0x02, // Report Count 2
       0x91,0x02, // Output (Variable)
    0xC0 , // End Collection


    0x09,0x68, // Usage Custom Force  Report
    0xA1,0x02, // Collection Datalink
       0x85,0x09, // Report ID 9
       0x09,0x22, // Usage Effect Block Index
       0x15,0x01, // Logical Minimum 1
       0x25,0x28, // Logical Maximum 28h (40d)
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x6C, // Usage Custom Force Data Offset
       0x15,0x00, // Logical Minimum 0
       0x26,0x10,0x27, // Logical Maximum 2710h (10000d)
       0x35,0x00, // Physical Minimum 0
       0x46,0x10,0x27, // Physical Maximum 2710h (10000d)
       0x75,0x10, // Report Size 10h (16d)
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x69, // Usage Custom Force Data
       0x15,0x81, // Logical Minimum 81h (-127d)
       0x25,0x7F, // Logical Maximum 7Fh (127d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x00, // Physical Maximum FFh (255d)
       0x75,0x08, // Report Size 8
       0x95,0x0C, // Report Count Ch (12d)
       0x92,0x02,0x01, // Output (Variable, Buffered)
    0xC0 , // End Collection


    0x09,0x66, // Usage Download Force Sample
    0xA1,0x02, // Collection Datalink
       0x85,0x0A, // Report ID 10
       0x05,0x01, // Usage Page Generic Desktop
       0x09,0x30, // Usage X
       0x09,0x31, // Usage Y
       0x15,0x81, // Logical Minimum 81h (-127d)
       0x25,0x7F, // Logical Maximum 7Fh (127d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x00, // Physical Maximum FFh (255d)
       0x75,0x08, // Report Size 8
       0x95,0x02, // Report Count 2
       0x91,0x02, // Output (Variable)
    0xC0 , // End Collection


    0x05,0x0F, // Usage Page Physical Interface
    0x09,0x77, // Usage Effect Operation Report
    0xA1,0x02, // Collection Datalink
       0x85,0x0B, // Report ID 11
       0x09,0x22, // Usage Effect Block Index
       0x15,0x01, // Logical Minimum 1
       0x25,0x28, // Logical Maximum 28h (40d)
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x78, // Usage Effect Operation
       0xA1,0x02, // Collection Datalink
          0x09,0x79, // Usage Op Effect Start
          0x09,0x7A, // Usage Op Effect Start Solo
          0x09,0x7B, // Usage Op Effect Stop
          0x15,0x01, // Logical Minimum 1
          0x25,0x03, // Logical Maximum 3
          0x75,0x08, // Report Size 8
          0x95,0x01, // Report Count 1
          0x91,0x00, // Output
       0xC0 , // End Collection


       0x09,0x7C, // Usage Loop Count
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x00, // Physical Maximum FFh (255d)
       0x91,0x02, // Output (Variable)
    0xC0 , // End Collection


    0x09,0x90, // Usage PID Block Free Report
    0xA1,0x02, // Collection Datalink
       0x85,0x0C, // Report ID 11
       0x09,0x22, // Usage Effect Block Index
       0x25,0x28, // Logical Maximum 28h (40d)
       0x15,0x01, // Logical Minimum 1
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
    0xC0 , // End Collection


    0x09,0x96, // Usage PID Device Control
    0xA1,0x02, // Collection Datalink
       0x85,0x0D, // Report ID 13  // ok, i get this on HID EP 1 after the PID POOL REPORT
       0x09,0x97, // Usage DC Enable Actuators
       0x09,0x98, // Usage DC Disable Actuators
       0x09,0x99, // Usage DC Stop All Effects
       0x09,0x9A, // Usage DC Device Reset
       0x09,0x9B, // Usage DC Device Pause
       0x09,0x9C, // Usage DC Device Continue
       0x15,0x01, // Logical Minimum 1
       0x25,0x06, // Logical Maximum 6
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x00, // Output
    0xC0 , // End Collection

    0x09,0x7D, // Usage Device Gain Report
    0xA1,0x02, // Collection Datalink
       0x85,0x0E, // Report ID 14
       0x09,0x7E, // Usage Device Gain
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x00, // Physical Maximum 255 
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
    0xC0 , // End Collection


    0x09,0x6B, // Usage Set Custom Force Report
    0xA1,0x02, // Collection Datalink
       0x85,0x0F, // Report ID 15
       0x09,0x22, // Usage Effect Block Index
       0x15,0x01, // Logical Minimum 1
       0x25,0x28, // Logical Maximum 28h (40d)
       0x35,0x01, // Physical Minimum 1
       0x45,0x28, // Physical Maximum 28h (40d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x6D, // Usage Sample Count
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x00, // Logical Maximum FFh (255d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x00, // Physical Maximum FFh (255d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x09,0x51, // Usage Sample Period
       0x66,0x03,0x10, // Unit 1003h (4099d)
       0x55,0xFD, // Unit Exponent FDh (253d)
       0x15,0x00, // Logical Minimum 0
       0x26,0xFF,0x7F, // Logical Maximum 7FFFh (32767d)
       0x35,0x00, // Physical Minimum 0
       0x46,0xFF,0x7F, // Physical Maximum 7FFFh (32767d)
       0x75,0x10, // Report Size 10h (16d)
       0x95,0x01, // Report Count 1
       0x91,0x02, // Output (Variable)
       0x55,0x00, // Unit Exponent 0
       0x66,0x00,0x00, // Unit 0
    0xC0 , // End Collection


    0x09,0xAB, // Usage Create New Effect Report
    0xA1,0x02, // Collection Datalink
       0x85,0x10, // Report ID 16
       0x09,0x25, // Usage Effect Type
       0xA1,0x02, // Collection Datalink
       0x09,0x26, // Usage ET Constant Force
       0x09,0x27, // Usage ET Ramp
       0x09,0x30, // Usage ET Square
       0x09,0x31, // Usage ET Sine
       0x09,0x32, // Usage ET Triangle
       0x09,0x33, // Usage ET Sawtooth Up
       0x09,0x34, // Usage ET Sawtooth Down
       0x09,0x40, // Usage ET Spring
       0x09,0x41, // Usage ET Damper
       0x09,0x42, // Usage ET Inertia
       0x09,0x43, // Usage ET Friction
       0x09,0x28, // Usage ET Custom Force Data
       0x25,0x0C, // Logical Maximum Ch (12d)
       0x15,0x01, // Logical Minimum 1
       0x35,0x01, // Physical Minimum 1
       0x45,0x0C, // Physical Maximum Ch (12d)
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0xB1,0x00, // Feature
    0xC0 , // End Collection


    0x05,0x01, // Usage Page Generic Desktop
    0x09,0x3B, // Usage Reserved
    0x15,0x00, // Logical Minimum 0
    0x26,0xFF,0x01, // Logical Maximum 1FFh (511d)
    0x35,0x00, // Physical Minimum 0
    0x46,0xFF,0x01, // Physical Maximum 1FFh (511d)
    0x75,0x0A, // Report Size Ah (10d)
    0x95,0x01, // Report Count 1
    0xB1,0x02, // Feature (Variable)
    0x75,0x06, // Report Size 6
    0xB1,0x01, // Feature (Constant)
 0xC0 , // End Collection


 0x05,0x0F, // Usage Page Physical Interface
 0x09,0x89, // Usage PID Block Load Status
 0xA1,0x02, // Collection Datalink
    0x85,0x11, // Report ID 17
    0x09,0x22, // Usage Effect Block Index
    0x25,0x28, // Logical Maximum 28h (40d)
    0x15,0x01, // Logical Minimum 1
    0x35,0x01, // Physical Minimum 1
    0x45,0x28, // Physical Maximum 28h (40d)
    0x75,0x08, // Report Size 8
    0x95,0x01, // Report Count 1
    0xB1,0x02, // Feature (Variable)
    0x09,0x8B, // Usage Block Load Status
    0xA1,0x02, // Collection Datalink
       0x09,0x8C, // Usage Block Load Success
       0x09,0x8D, // Usage Block Load Full
       0x09,0x8E, // Usage Block Load Error
       0x25,0x03, // Logical Maximum 3
       0x15,0x01, // Logical Minimum 1
       0x35,0x01, // Physical Minimum 1
       0x45,0x03, // Physical Maximum 3
       0x75,0x08, // Report Size 8
       0x95,0x01, // Report Count 1
       0xB1,0x00, // Feature
		/*
		FIELD ADDED
		*/
		0x09,0xAC,               //   [0x19]USAGE(RAM POOL AVAILABLE)
		0x15,0x00,               //   [0x1A]LOGICAL_MINIMUM
		0x26,0x96,0x00,          //   [0x1B]LOGICAL_MAXIMUM
		0x75,0x08,               //   [0x1C]REPORT_SIZE
		0x95,0x01,               //   [0x1D]REPORT_COUNT
        0xB1,0x02, // Feature (Variable)
    0xC0 , // End Collection

/*
    0x09,0xAC, // Usage Undefined
    0x15,0x00, // Logical Minimum 0
    0x27,0xFF,0xFF,0x00,0x00, // Logical Maximum FFFFh (65535d)
    0x35,0x00, // Physical Minimum 0
    0x47,0xFF,0xFF,0x00,0x00, // Physical Maximum FFFFh (65535d)
    0x75,0x10, // Report Size 10h (16d)
    0x95,0x01, // Report Count 1
    0xB1,0x00, // Feature
*/
 0xC0 , // End Collection


 0x09,0x7F, // Usage PID Pool Report
 0xA1,0x02, // Collection Datalink
    0x85,0x22, // Report ID 17
    0x09,0x80, // Usage RAM Pool size
    0x75,0x08, // Report Size 8
    0x95,0x01, // Report Count 1
    0x15,0x00, // Logical Minimum 0
    0x35,0x00, // Physical Minimum 0
//-4 byte 
    0x26,0x96,0x00, // Logical Maximum FFFFh (65535d)
    0x46,0x96,0x00, // Physical Maximum FFFFh (65535d)
    0xB1,0x02, // Feature (Variable)

/*
+13 bytes  
ADDING ROM SIZE 0
*/
	0x09,0x81,               //   [0x0B]USAGE(ROM POOL SIZE)
	0x75,0x08,               //   [0x0F]REPORT_SIZE
	0x15,0x00,               //   [0x0C]LOGICAL_MINIMUM
	0x26,0x96,0x00,               //   [0x0D]LOGICAL_MAXIMUM 150
	0x95,0x01,               //   [0x0E]REPORT_COUNT
    0xB1,0x02, 				 //   Feature (Variable)
//+13
//-------------------------------end adding rom size
	0x09,0x82,               //   [0x13]USAGE(ROM EFFECT BLOCK COUNT)
	0x75,0x08,               //   [0x14]REPORT_SIZE 8
	0x95,0x01,               //   [0x17]REPORT_COUNT 1
	0x15,0x00,               //   [0x15]LOGICAL_MINIMUM 0
	0x26,0x96,0x00,          //   [0x16]LOGICAL_MAXIMUM 150
	0xB1,0x02,               //   [0x18]FEATURE (Variable)

//13+13-4=+22
//-------------------------------end adding rom effect block count
    0x09,0x83, // Usage Simultaneous Effects Max
    0x26,0xFF,0x00, // Logical Maximum FFh (255d)
    0x46,0xFF,0x00, // Physical Maximum FFh (255d)
    0x75,0x08, // Report Size 8
    0x95,0x01, // Report Count 1
    0xB1,0x02, // Feature (Variable)

    0x09,0xA9, // Usage Device Managed Pool
    0x09,0xAA, // Usage Shared Parameter Blocks
    0x75,0x01, // Report Size 1
    0x95,0x02, // Report Count 2
    0x15,0x00, // Logical Minimum 0
    0x25,0x01, // Logical Maximum 1
    0x35,0x00, // Physical Minimum 0
    0x45,0x01, // Physical Maximum 1
    0xB1,0x02, // Feature (Variable)
    0x75,0x06, // Report Size 6
    0x95,0x01, // Report Count 1

    0xB1,0x03, // Feature (Constant, Variable)
    0xC0, // End Collection
 0xC0 // End Collection
 
}
};
/** EOF usb_descriptors.c ***************************************************/

#endif
